


<?php $__env->startSection('content'); ?>
<div class="container-fluid">

<!-- Page Heading -->



<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Quản lý đơn hàng</h6>
        
    </div>
    <div class="card-body">
    <h2>
                                            <?php if(session()->has('error')): ?>
                                                <p class="alert alert-danger"><?php echo e(session()->get('error')); ?></p>
                                            <?php elseif(session()->has('mess')): ?>
                                                <p class="alert alert-success"><?php echo e(session()->get('mess')); ?></p>
                                            <?php elseif(session()->has('messUpdate')): ?>
                                                <p class="alert alert-success"><?php echo e(session()->get('messUpdate')); ?></p>
                                            <?php elseif(session()->has('messInsert')): ?>
                                                <p class="alert alert-success"><?php echo e(session()->get('messInsert')); ?></p>
                                            <?php endif; ?>
                
                                        </h2>
   
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Mã đơn hàng</th>
                        <th>Email</th>
                        <th>Ngày đặt hàng</th>
                        <th>Tên người nhận</th>
                        <th>Số điện thoại</th>
                        <th>Địa chỉ</th>
                        <th>Mô tả</th>
                        <th>Tổng tiền</th>
                        <th>Trạng thái</th>
                        <th></th>
                       
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                    <th>Mã đơn hàng</th>
                        <th>Email</th>
                        <th>Ngày đặt hàng</th>
                        <th>Tên người nhận</th>
                        <th>Số điện thoại</th>
                        <th>Địa chỉ</th>
                        <th>Mô tả</th>
                        <th>Tổng tiền</th>
                        <th>Trạng thái</th>
                        <th></th>
                       
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
                    <tr>
                        <td><?php echo e($item->madonhang); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        <td> <?php echo e($item->ngaydat); ?> </td>
                        <td><?php echo e($item->ten_nguoinhan); ?> </td>
                        <td><?php echo e($item->sdt_nguoinhan); ?> </td>
                        <td><?php echo e($item->diachi_nguoinhan); ?> </td>
                        <td><?php echo e($item->mota); ?> </td>
                        <td><?php echo e(number_format($item->total_money)); ?> VNĐ</td>
                        <td><?php echo e($item->status); ?></td>
                        <td>
                            <?php if($item->status == 'Đã giao hàng' ): ?>
                            <form action="/admin/order/destroy/<?php echo e($item->madonhang); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="delete">
                                <input type="hidden" name="madonhang" value="<?php echo e($item->madonhang); ?>">
                                <input type="submit" value="xoa" class="btn btn-danger" onclick="myFunction()">
                            </form>
                            <?php elseif($item->status == '0'): ?>
                            <div id="action">
                                                                <form action="/admin/order/check/<?php echo e($item->madonhang); ?>" method="post">
                                                                    <?php echo csrf_field(); ?>
                                                             
                                                                        <input type="hidden" name="_method" value="put">
                                                                        <input type="hidden" name="madonhang" value="<?php echo e($item->madonhang); ?>">
                                                                        <input type="submit" value="Xác nhận đơn hàng" class="btn btn-warning" onclick="removeColor()">
                                                                </form>
                                                              
                                                                </div> 
                            
                            <?php else: ?>
                            <div id="action">
                                                                <form action="/admin/order/check1/<?php echo e($item->madonhang); ?>" method="post">
                                                                    <?php echo csrf_field(); ?>
                                                             
                                                                        <input type="hidden" name="_method" value="put">
                                                                        <input type="hidden" name="madonhang" value="<?php echo e($item->madonhang); ?>">
                                                                        <input type="submit" value="Xác nhận đã giao hàng" class="btn btn-success" onclick="removeColor()">
                                                                </form>
                                                              
                                                                </div> 
                            <?php endif; ?>                  
                        </td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
<!-- /.container-fluid -->

</div>
<script>
//             function removeClass() {
//   let status = document.getElementById('status');
//   /* xoá class  title*/
// //   element.classList.remove('title');
// }
// removeClass();
function removeColor(){
let status = document.getElementById('status');
status.classList.remove('btn-danger');
}
// status.classList.add('btn-success');

        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/admin/layouts/layoutadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\webdoan\resources\views/admin/order/index.blade.php ENDPATH**/ ?>