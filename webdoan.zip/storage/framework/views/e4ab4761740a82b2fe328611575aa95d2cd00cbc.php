


<?php $__env->startSection('content'); ?>
<div class="container-fluid">

<!-- Page Heading -->


<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Thêm Danh Mục</h6>
       
    </div>
    <div class="card-body">
        <?php if(session()->has('error')): ?>
             <p class="alert alert-danger"><?php echo e(session()->get('error')); ?></p>
        <?php elseif(session()->has('mess')): ?>
        <p class="alert alert-success"><?php echo e(session()->get('mess')); ?></p>
        <?php endif; ?>
        <div class="modal-body">
      <form action="/admin/category/store" method="POST">
    <?php echo csrf_field(); ?>
<table align="center">
        <tr>
            <td colspan="2">Mã danh mục</td>
            <td colspan="2"><input type="text" name="madanhmuc" require value="<?php echo e(old('madanhmuc')); ?>"></td>
            <?php $__errorArgs = ['madanhmuc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <td><div class="alert alert-danger"> <?php echo e($message); ?>    </div></td>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </tr>
        <tr>
            <td colspan="2">Tên danh mục</td>
            <td colspan="2"><input type="text" name="tendanhmuc" value="<?php echo e(old('tendanhmuc')); ?>"></td>
            <?php $__errorArgs = ['tendanhmuc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <td><div class="alert alert-danger"> <?php echo e($message); ?>    </div></td>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </tr>
        <tr>
            
          
           <td></td>
           
           
           <td colspan="2" > <input type="submit" value="Lưu" class="btn btn-outline-success" >
          
            </td>
            <td><a type="button" class="btn btn-outline-danger" href="/admin/category" data-dismiss="modal">Đóng</a></td>
        </tr>
    </table>
</form>
            
      
        
    </div>
</div>

</div>
<!-- /.container-fluid -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/admin/layouts/layoutadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\webdoan\resources\views/admin/category/create.blade.php ENDPATH**/ ?>