


<?php $__env->startSection('content'); ?>
<div class="container-fluid">

<!-- Page Heading -->


<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Thêm Sản phẩm</h6>
       
    </div>
    <div class="card-body">
        <?php if(session()->has('error')): ?>
             <p class="alert alert-danger"><?php echo e(session()->get('error')); ?></p>
        <?php elseif(session()->has('mess')): ?>
        <p class="alert alert-success"><?php echo e(session()->get('mess')); ?></p>
        <?php endif; ?>
        <div class="modal-body">
        <form action="/admin/product/edit/{$id}" method="POST"  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
<table align="center">
        <tr>
            <td colspan="2">Mã sản phẩm</td>
            <td colspan="2"><input type="text" readonly name="masp" value="<?php echo e($data->masp); ?>"></td>
            <?php $__errorArgs = ['masp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <td><div class="alert alert-danger"> <?php echo e($message); ?>    </div></td>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
        </tr>
        <tr>
            <td colspan="2">Tên sản phẩm</td>
            <td colspan="2"><input type="text" name="tensp" value="<?php echo e($data->tensp); ?>"></td>
            <?php $__errorArgs = ['tensp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <td><div class="alert alert-danger"> <?php echo e($message); ?>    </div></td>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
        </tr>
        <tr>
            <td colspan="2">Số lượng</td>
            <td colspan="2"><input type="number" name="soluong" value="<?php echo e($data->soluong); ?>"></td>
            
        </tr>
        <tr>
            <td colspan="2">Giá</td>
            <td colspan="2"><input type="number" name="gia" value="<?php echo e($data->gia); ?>" ></td>
            
        </tr>
        <tr>
            <td colspan="2">Mô tả</td>
            <td colspan="2"><textarea type="text" id="mota" name="mota"> <?php echo e($data->mota); ?></textarea>

            
            <script>
                CKEDITOR.replace('mota');
            </script>
            </td>
            
        </tr>
        <tr>
            <td colspan="2">Hình ảnh</td>
            <td colspan="2"><input type="file" name="hinhanh"   > hình ảnh hiện tại: <?php echo e($data->hinhanh); ?></td>
        </tr>
        <tr>
            <td colspan="2">Trạng thái</td>
            <td colspan="2">
                <select name="trangthai" class="form-select" >
                    <option value="1">Còn hàng</option>
                    <option value="0" >Hết hàng</option>
                </select>
            </td>
       
            
        </tr>
        <tr>
            <td colspan="2"  >Danh mục</td>
            <td colspan="2">
                <select name="madanhmuc" class="form-select">
                <option value="<?php echo e($data->madanhmuc); ?>" selected ><?php echo e($data->cat->tendanhmuc); ?> </option>
                   <?php $__currentLoopData = $ct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->madanhmuc); ?>"><?php echo e($item->tendanhmuc); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
       
            
        </tr>
        <tr>
            <td colspan="2">Thương hiệu</td>
            <td colspan="2" >
                <select  name="math" class="form-select">
                <option value="<?php echo e($data->math); ?>" selected ><?php echo e($data->pub->teth); ?> </option>
                <?php $__currentLoopData = $th; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                    <option value="<?php echo e($item->math); ?> " ><?php echo e($item->teth); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
       
            
        </tr>
        <tr>
            
          
           <td></td>
           
           
           <td colspan="2" > <input type="submit" value="Lưu" class="btn btn-outline-success" >
           <input type="hidden" name="_method" value="put">
            </td>
            <td><button type="button" class="btn btn-outline-danger" data-dismiss="modal">Đóng</button></td>
        </tr>
    </table>
</form>
            
      
        
    </div>
</div>

</div>
<!-- /.container-fluid -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/admin/layouts/layoutadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\webdoan\resources\views//admin/product/edit.blade.php ENDPATH**/ ?>