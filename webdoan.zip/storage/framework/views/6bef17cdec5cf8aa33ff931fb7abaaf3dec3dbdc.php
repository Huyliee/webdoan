


<?php $__env->startSection('content'); ?>
<div class="container-fluid">

<!-- Page Heading -->


<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Quản lý danh mục</h6>
       
    </div>
    <div class="card-body">
        <?php if(session()->has('error')): ?>
             <p class="alert alert-danger"><?php echo e(session()->get('error')); ?></p>
        <?php elseif(session()->has('mess')): ?>
        <p class="alert alert-success"><?php echo e(session()->get('mess')); ?></p>
        <?php endif; ?>
                                          
        <div class="table-responsive">
        
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
      
                <thead>
                
                    <tr>
                        <th>STT</th>
                        <th>ID</th>
                        <th>Tên danh mục</th>
                        <!-- <th>         <button><a href="/admin/category/create"> Them Danh Muc</a></button></th> -->
                        <th><a  href="/admin/category/create" class="btn btn-primary"   >Thêm Danh Mục Mới</a></th>
 
                       
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>STT</th>
                        <th>ID</th>
                        <th>Tên danh mục</th>
                        <th></th>
                        <th></th>
                       
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $arrCate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index+1); ?></td>
                        <td><?php echo e($item->madanhmuc); ?></td>
                        <td> <?php echo e($item->tendanhmuc); ?> </td>
                        <td>
                            <form  action="/admin/category/destroy/<?php echo e($item->madanhmuc); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="delete">
                                <input type="hidden" name="madanhmuc" value="<?php echo e($item->madanhmuc); ?>">
                                <input type="submit" onclick="myFunction()" value="Xóa"  class="btn btn-danger">
                            </form> <br>
                            <a  class="btn btn-primary"   href="/admin/category/edit/<?php echo e($item->madanhmuc); ?>">Sửa</a>
 
                        </td>
                     
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
            </table>
      
        </div>
    </div>
</div>

</div>
<!-- /.container-fluid -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/admin/layouts/layoutadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\webdoan\resources\views/admin/category/index.blade.php ENDPATH**/ ?>