<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="/admin/product/storeImg" method="POST"  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
<table align="center">

        <tr>
            <td colspan="2">Hình ảnh</td>
            <td colspan="2"><input type="file" name="img"></td>
        </tr>
        <tr>
            <td colspan="2"  >Tên sản phẩm</td>
            <td colspan="2">
                <select name="masp" class="form-select">
                   <?php $__currentLoopData = $arrProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->masp); ?>"><?php echo e($item->masp); ?> - <?php echo e($item->tensp); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
       
            
        </tr>
        
        <tr>
            
          
           <td></td>
           
           
           <td colspan="2" > <input type="submit" value="Lưu" class="btn btn-outline-success" >
            
            </td>
            <td><button type="button" class="btn btn-outline-danger" data-dismiss="modal">Đóng</button></td>
        </tr>
    </table>
</form>
</body>
</html><?php /**PATH D:\laravel\webdoan\resources\views/admin/product/createImg.blade.php ENDPATH**/ ?>