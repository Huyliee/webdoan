

<?php echo $__env->make('/admin/layouts/layoutadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\webdoan\resources\views/admin/index.blade.php ENDPATH**/ ?>