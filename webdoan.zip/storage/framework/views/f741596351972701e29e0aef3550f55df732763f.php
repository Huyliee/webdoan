


<?php $__env->startSection('content'); ?>
<div class="container-fluid">

<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">Tables</h1>
<p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
    For more information about DataTables, please visit the <a target="_blank"
        href="https://datatables.net">official DataTables documentation</a>.</p>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
        <h5><a href="/admin/category/create"> Them moi</a></h5>
    </div>
    <div class="card-body">
    <?php if(session()->has('error')): ?>
             <p class="alert alert-danger"><?php echo e(session()->get('error')); ?></p>
        <?php elseif(session()->has('mess')): ?>
        <p class="alert alert-success"><?php echo e(session()->get('mess')); ?></p>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>STT</th>
                        <th>Email</th>
                        <th>Ten Khach Hang</th>
                        <th>Dia chi</th>
                        <th>gioi tinh</th>
                        <th>So dien thoai</th>
                        <th>Ngay sinh</th>
                        <th></th>
                       
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                    <th>STT</th>
                        <th>Email</th>
                        <th>Ten Khach Hang</th>
                        <th>Dia chi</th>
                        <th>gioi tinh</th>
                        <th>So dien thoai</th>
                        <th>Ngay sinh</th>
                        <th></th>
                       
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
                    <tr>
                        <td><?php echo e($index+1); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        <td> <?php echo e($item->tenkh); ?> </td>
                        <td><?php echo e($item->diachi); ?> </td>
                        <td><?php echo e($item->gioitinh); ?> </td>
                        <td><?php echo e($item->sodienthoai); ?> </td>
                        <td><?php echo e($item->ngaysinh); ?> </td>
                        <td>
                            <form action="/admin/users/destroy/<?php echo e($item->email); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="delete">
                                <input type="hidden" name="email" value="<?php echo e($item->email); ?>">
                                <input type="submit" value="xoa" onclick="myFunction()" class="btn btn-danger">
                            </form>
                        </td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
<!-- /.container-fluid -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/admin/layouts/layoutadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\webdoan\resources\views/admin/users/index.blade.php ENDPATH**/ ?>