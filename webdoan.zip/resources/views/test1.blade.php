Cảm ơn bạn đã đặt hàng tại Website của chúng tôi!!!
<br>
Chúng tôi sẽ liên hệ với bạn để xác nhận đơn hàng trong thời gian sớm nhất!!
<br>
Thanks you ❤️